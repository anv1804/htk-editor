Ghép base.png + một PNG trong outfits/ + hair.png.
Giữ nguyên kích thước sheet 256 x 448 và bố cục 4 cột x 7 hàng.
Các lớp có cùng tọa độ frame. Không tự cắt gọn riêng từng ảnh.
Chỉ có pixel nhìn thấy trong nguồn: tóc khuất sau áo chưa được dựng bổ sung.
Kiểm tra lại vùng che khuất nếu ghép với kiểu áo khác.
