HKT UI Forge / Xianxia v2

Copy ui_forge into your Godot 4 project root.
Open HUD.tscn or instantiate it in your game. Base canvas: 640x360.
Use integer scaling (2x for 1280x720), Nearest filter, and integer positions.
Frame and button interiors are transparent. Background tiles are separate layers.
Skill circles are baked at each instance size with one opaque 1px contour, no shadow or fill. Resize in UI Forge and export again.
Connect Button.pressed to gameplay actions.
The joystick handles mouse and touch; connect direction_changed(Vector2) to movement.
Joystick direction resets on release or window focus loss. Positive Y points down.
Scroll_v.tscn / Scroll_h.tscn are functional VScrollBar / HScrollBar scenes. Connect value_changed to your content. HUD tracks and grabbers remain separate artwork layers for manual assembly.
Equipment previews and chat frames are empty containers; connect character data and chat logic in your game.
Progress bars contain sample values. Bind values to your character data.
Import preset.json in UI Forge to continue editing, including hand-painted pixel overrides.
Artwork is generated from geometry; reference sheet pixels are not included.
