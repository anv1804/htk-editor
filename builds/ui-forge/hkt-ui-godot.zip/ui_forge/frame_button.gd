extends Button
func _ready() -> void:
    mouse_entered.connect(func(): modulate = Color(1.15, 1.15, 1.15))
    mouse_exited.connect(func(): modulate = Color.WHITE)
    button_down.connect(func(): modulate = Color(0.72, 0.78, 0.74))
    button_up.connect(func(): modulate = Color.WHITE)
