extends Control
## Connect direction_changed to your character movement input.
signal direction_changed(value: Vector2)
@export var radius: float = 30.0
var direction: Vector2 = Vector2.ZERO
var _finger: int = -2
@onready var thumb: TextureRect = $Thumb
var _rest := Vector2(35, 35)

func _gui_input(event: InputEvent) -> void:
    if _finger != -2:
        return
    if event is InputEventScreenTouch and event.pressed:
        _finger = event.index
        _update_stick(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _finger = -1
        _update_stick(event.position)
        accept_event()

func _input(event: InputEvent) -> void:
    if _finger == -2:
        return
    if event is InputEventScreenTouch and event.index == _finger and not event.pressed:
        _release()
    elif event is InputEventScreenDrag and event.index == _finger:
        _update_stick(get_global_transform_with_canvas().affine_inverse() * event.position)
    elif _finger == -1 and event is InputEventMouseMotion:
        _update_stick(get_global_transform_with_canvas().affine_inverse() * event.position)
    elif _finger == -1 and event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
        _release()

func _update_stick(point: Vector2) -> void:
    var offset := (point - Vector2(54, 54)).limit_length(maxf(radius, 1.0))
    thumb.position = _rest + offset
    direction = offset / maxf(radius, 1.0)
    direction_changed.emit(direction)

func _release() -> void:
    _finger = -2
    direction = Vector2.ZERO
    thumb.position = _rest
    direction_changed.emit(direction)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT and is_instance_valid(thumb):
        _release()
